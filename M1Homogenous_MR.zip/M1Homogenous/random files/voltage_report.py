from bmtk.analyzer.compartment import plot_traces

_ = plot_traces(config_file='simulation_config_short.json', report_path='/Users/', node_ids=[999])
