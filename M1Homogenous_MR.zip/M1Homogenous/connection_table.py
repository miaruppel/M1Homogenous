from bmtk.utils.sonata import File
import numpy as np
import pandas as pd

net = File(data_files=['network/cortex_cortex_edges.h5', 'network/cortex_nodes.h5'],
           data_type_files=['network/cortex_cortex_edge_types.csv', 'network/cortex_node_types.csv'])

print("This is gonna take a sec btw")
print('Contains nodes: {}'.format(net.has_nodes))
print('Contains edges: {}'.format(net.has_edges))


file_edges = net.edges
print('Edge populations in file: {}'.format(file_edges.population_names))
recurrent_edges = file_edges['cortex_to_cortex']

#conver_onto = 925
conver_onto = np.arange(0, 1000, 1)
#conver_onto = np.delete(conver_onto, np.where(conver_onto == 3208))
#conver_onto = np.delete(conver_onto, np.where(conver_onto == 3266))
#conver_onto = np.delete(conver_onto, np.where(conver_onto == 3390))

scale = 4
con_count = 0
CP_count = 0
CS_count = 0
FSI_count = 0
LTS_count = 0
best_excit_count = 0
best_excit_cell = 0
CP = []
CS = []
LTS = []
FSI = []
total_excit = []
total_inhib = []
net_excit = []
nex_excit_PV = []
label = []
for i in range(len(conver_onto)):
    CP_count = 0
    CS_count = 0
    FSI_count = 0
    LTS_count = 0
    if (conver_onto[i] >= 0 and conver_onto[i] <= 399):
        label.append('CP Cell')
    if (conver_onto[i] >= 400 and conver_onto[i] <= 799):
        label.append('CS Cell')
    if (conver_onto[i] >= 800 and conver_onto[i] <= 919):
        label.append('FSI Cell')
    if (conver_onto[i] >= 920 and conver_onto[i] <= 999):
        label.append('LTS Cell')
    for edge in recurrent_edges.get_target(conver_onto[i]):  # we can also use get_targets([id0, id1, ...])
        assert (edge.target_node_id == conver_onto[i])
        if ((edge.source_node_id >= 0) & (edge.source_node_id <= 399)):
            CP_count = CP_count + 1
        if ((edge.source_node_id >= 400) & (edge.source_node_id <= 799)):
            CS_count = CS_count + 1
        if ((edge.source_node_id >= 800) & (edge.source_node_id <= 919)):
            FSI_count = FSI_count + 1
        if ((edge.source_node_id >= 920) & (edge.source_node_id <= 999)):
            LTS_count = LTS_count + 1
        #print("cell %d has cell %d converging onto it" % (conver_onto, edge.source_node_id))
        con_count += 1
    CP.append(CP_count)
    CS.append(CS_count)
    LTS.append(LTS_count)
    FSI.append(FSI_count)
    tot_exc = CP_count + CS_count
    tot_inh = FSI_count + LTS_count
    total_excit.append(tot_exc)
    total_inhib.append(tot_inh)
    net_excit.append(tot_exc - tot_inh)
    #nex_excit_PV.append(tot_exc - PV_count)

#print(len(label))
#print(len(conver_onto))
#print(len(CP))
d = {'cell id': conver_onto,'Cell Type':label, 'CP Convergence': CP, 'CS Convergence': CS, 'LTS Convergence': LTS,
     'FSI Convergence': FSI, 'Total Exc Convergence': total_excit, 'Total Inh Convergence': total_inhib,
     'Net Exc':net_excit}
df = pd.DataFrame(data=d)
df.to_csv('connection table.csv')


    #print('There are {} connections onto target node #{}'.format(best_con_count, best_con_count))
    #print('There are {} PN_A connections onto target node #{}'.format(best_PN_A_count, best_excit_cell))
    #print('There are {} PN_C connections onto target node #{}'.format(best_PN_C_count, best_excit_cell))
    #print('There are {} excitatory connections onto target node #{}'.format((best_PN_A_count+best_PN_C_count), best_excit_cell))
    #print('There are {} PV connections onto target node #{}'.format(best_PV_count, best_excit_cell))
    #print('There are {} SOM connections onto target node #{}'.format(best_SOM_count, best_excit_cell))
    #print('There are {} inhibitory connections onto target node #{}'.format((best_PV_count + best_SOM_count), best_excit_cell))
    #print('There are {} net excitatory connections onto target node #{}'.format(((best_PN_A_count + best_PN_C_count) - (best_PV_count)), best_excit_cell))

